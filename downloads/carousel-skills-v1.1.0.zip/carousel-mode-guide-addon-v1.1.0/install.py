#!/usr/bin/env python3
"""Install the portable carousel skills into an explicitly selected directory."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination',required=True,help='Your host skill root directory')
    parser.add_argument('--only',choices=['carousel-mode-guide','misconception-object-carousel'])
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    expected=set(manifest['sha256'])|{'manifest.json'}
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if expected!=actual or any(p.is_symlink() for p in root.rglob('*')):
        raise SystemExit('Package inventory differs or contains symbolic links; nothing installed')
    for rel,digest in manifest['sha256'].items():
        path=root/rel
        if not path.resolve().is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise SystemExit('Integrity check failed: '+rel)
    names=manifest['skills'] if not args.only else [args.only]
    if args.only=='carousel-mode-guide':
        names=manifest['skills'] # C01 is a bundled dependency of the guide.
    destination=Path(args.destination).expanduser().resolve()
    if destination.is_relative_to(root):
        raise SystemExit('Choose a destination outside the extracted package')
    for name in names:
        target=destination/name
        if target.exists() or target.is_symlink():
            raise SystemExit('Destination already exists; nothing installed: '+str(target))
    if args.dry_run:
        print('Verified. Would install: '+', '.join(str(destination/n) for n in names))
        return
    destination.mkdir(parents=True,exist_ok=True)
    installed=[]
    with tempfile.TemporaryDirectory(prefix='.carousel-stage-',dir=destination) as staging:
        stage=Path(staging)
        for name in names:shutil.copytree(root/name,stage/name)
        try:
            for name in names:
                target=destination/name
                if target.exists() or target.is_symlink():
                    raise FileExistsError('Destination appeared while staging: '+str(target))
                (stage/name).rename(target)
                installed.append(target)
        except Exception:
            for target in installed:shutil.rmtree(target)
            raise
    print('Installed: '+', '.join(str(p) for p in installed))
    print('Reload discovery in your host, or explicitly read SKILL.md. No host configuration was changed.')

if __name__=='__main__':main()
